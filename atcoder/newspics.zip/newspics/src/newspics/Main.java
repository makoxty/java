package newspics;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Main {

	public static void main(String[] args) throws IOException {
		final int cutTitle = 10;
		final int cutText = 30;

		String input = "";
		String cut = "";
		String fileName = "";
		String extension = "";
		for (int i = 0; i < args.length; ++i) {
			switch (args[i]) {
			case "-i":
				input = args[i + 1];
				extension = input.substring(input.length() - 3);
				break;
			case "-c":
				cut = args[i + 1];
				break;
			case "-o":
				fileName = args[i + 1];
				break;
			}
		}
		if (extension.equals("rss") && cut != "") {
			parseXML(input, cut, cutTitle, cutText);
		} else if (extension.equals("txt")) {
			if (input != "" && fileName != "" && cut != "") {
				parseTxt(input, fileName, cut);
			} else {
				System.out.println("引数のパラメータが足りません");
			}
		}
	}

	private static void parseTxt(String input, String fileName, String cut) throws IOException {
		Path file = Paths.get(input);
		String text = Files.readString(file);
		System.out.println(text.contains("ユーザベース"));
		if (cut.equals("cut")) {
			if (text.contains("ユーザベース")) {
				String res = text.replace("ユーザベース", "UZABASE");
				try {
					File newFile = new File(fileName);
					FileWriter filewriter = new FileWriter(res);
				} catch (IOException e) {
					System.out.println(e);
				}
			}
		}
	}

	public static void parseXML(String path, String cut, int cutTitle, int cutText) {
		if (cut != "") {
			try {
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document document = builder.parse(path);
				Element root = document.getDocumentElement();

				NodeList channel = root.getElementsByTagName("channel");
				NodeList title = ((Element) channel.item(0)).getElementsByTagName("title");
				System.out.println("\nTitle: " + title.item(0).getFirstChild().getNodeValue() + "\n");

				NodeList item_list = root.getElementsByTagName("item");
				for (int i = 0; i < item_list.getLength(); i++) {
					Element element = (Element) item_list.item(i);
					NodeList item_title = element.getElementsByTagName("title");
					NodeList item_description = element.getElementsByTagName("description");
					System.out.println(" title: " + item_title.item(0).getFirstChild().getNodeValue().substring(0, cutTitle));
					System.out.println(" description: " + item_description.item(0).getFirstChild().getNodeValue().substring(0, cutText));
				}
			} catch (IOException e) {
				System.out.println("IO Exception");
			} catch (ParserConfigurationException e) {
				System.out.println("Parser Configuration Exception");
			} catch (SAXException e) {
				System.out.println("SAX Exception");
			}
			return;
		}
	}

}
